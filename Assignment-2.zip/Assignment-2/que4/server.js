const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');
const session = require('express-session');
const methodOverride = require('method-override');
const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method')); // For PUT and DELETE methods
app.set('view engine', 'ejs');

// Set views directory
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Session setup
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
}));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/studentDB', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error(err));

// Student Schema
const studentSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true },
    password: String
});

const Student = mongoose.model('Student', studentSchema);

// Middleware for JWT verification
const authenticateJWT = (req, res, next) => {
    const token = req.session.token;
    if (!token) return res.redirect('/'); // Redirect if not logged in

    jwt.verify(token, 'your_jwt_secret', (err, user) => {
        if (err) return res.redirect('/'); // Redirect if token is invalid
        req.user = user;
        next();
    });
};

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

// Register
app.post('/register', async (req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const newStudent = new Student({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
    });

    try {
        await newStudent.save();
        res.status(201).send('Student registered');
    } catch (error) {
        res.status(400).send('Error registering student');
    }
});

// Login
app.post('/login', async (req, res) => {
    const student = await Student.findOne({ email: req.body.email });
    if (student && (await bcrypt.compare(req.body.password, student.password))) {
        const token = jwt.sign({ email: student.email }, 'your_jwt_secret', { expiresIn: '1h' });
        req.session.token = token;
        res.redirect('/students'); // Redirect to the students page
    } else {
        res.status(403).send('Invalid credentials');
    }
});

// Logout
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) return res.status(500).send('Could not log out');
        res.redirect('/');
    });
});

// View students
app.get('/students', authenticateJWT, async (req, res) => {
    try {
        const students = await Student.find();
        res.render('student', { students });  // Renders the student.ejs view
    } catch (error) {
        res.status(500).send('Error retrieving students');
    }
});
// Add student form
app.get('/students/new', authenticateJWT, (req, res) => {
    res.render('insert');
});

// Handle adding a new student
app.post('/students', authenticateJWT, async (req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const newStudent = new Student({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
    });

    try {
        await newStudent.save();
        res.redirect('/students');
    } catch (error) {
        res.status(400).send('Error creating student');
    }
});

// Update student form
app.get('/students/:id/edit', authenticateJWT, async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        res.render('update', { student });
    } catch (error) {
        res.status(400).send('Error retrieving student');
    }
});

// Handle updating a student
app.put('/students/:id', authenticateJWT, async (req, res) => {
    const updateData = {
        name: req.body.name,
        email: req.body.email,
    };

    if (req.body.password) {
        updateData.password = await bcrypt.hash(req.body.password, 10);
    }

    try {
        await Student.findByIdAndUpdate(req.params.id, updateData);
        res.redirect('/students');
    } catch (error) {
        res.status(400).send('Error updating student');
    }
});

// Handle deleting a student
app.delete('/students/:id', authenticateJWT, async (req, res) => {
    try {
        await Student.findByIdAndDelete(req.params.id);
        res.redirect('/students');
    } catch (error) {
        res.status(400).send('Error deleting student');
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
