const express = require('express');
const session = require('express-session');
const RedisStore = require('connect-redis').default; // Import Redis store
const flash = require('connect-flash');
const bodyParser = require('body-parser');
const redis = require('redis');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8000;


// Configure Redis client
// const redisClient = redis.createClient();
const redisClient = redis.createClient({
    host: '127.0.0.1', // Change if necessary
    port: 6379 // Change if necessary
});

redisClient.on('error', (err) => console.log('Redis Client Error', err));

// Simple in-memory user store for demonstration purposes
const users = [{ username: 'testuser', password: 'password123' }];

// Setup session with Redis store
app.use(session({
    store: new RedisStore({ client: redisClient }),
    secret: 'secret_key', // Replace with a strong secret in production
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 60000 } // 1 minute
}));

// Flash messages middleware
app.use(flash());

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Render login form
app.get('/login', (req, res) => {
    res.render('login', { messages: req.flash('error') });
});

// Handle login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Check user credentials
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        req.session.user = user;
        req.flash('success', 'Logged in successfully!');
        return res.redirect('/dashboard');
    }

    req.flash('error', 'Invalid username or password');
    res.redirect('/login');
});

// Render dashboard
app.get('/dashboard', (req, res) => {
    if (!req.session.user) {
        req.flash('error', 'Please log in first');
        return res.redirect('/login');
    }
    res.render('dashboard', { user: req.session.user });
});

// Logout
app.get('/logout', (req, res) => {
    req.flash('success', 'Logged out successfully');
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/dashboard');
        }
        res.redirect('/login');
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

// Connect to Redis
(async () => {
    try {
        await redisClient.connect();
        console.log('Connected to Redis');
    } catch (err) {
        console.error('Redis Client Error', err);
    }
})();
